import test from "node:test";
import assert from "node:assert/strict";
import { seed } from "../server/seed.js";
import * as d from "../server/domain.js";
const user = (db) => db.users[0];
test("北京时间自然日与滚动时间独立，缺截止不进入截止统计", () => {
  const db = seed();
  const now = new Date("2026-10-14T00:00:00+08:00");
  const j = {
    ...db.jobs[0],
    uploadedAt: "2026-10-13T23:59:00+08:00",
    deadline: null,
  };
  assert.equal(d.publicationLabel(j, now), "昨日发布");
  assert.equal(d.matches(j, { scope: "new24" }, now), true);
  assert.equal(d.matches(j, { scope: "closing" }, now), false);
  assert.equal(d.day("2026-10-13T18:00:00Z"), "2026-10-14");
});
test("修改上传时间影响最新与日报，草稿和下架排除", () => {
  const db = seed();
  assert.equal(d.statistics(db).total, 18);
  db.jobs[0].hidden = true;
  assert.equal(d.statistics(db).total, 17);
  const j = db.jobs[1];
  j.uploadedAt = new Date(Date.now() - 100 * 3600000).toISOString();
  assert.equal(d.queryJobs(db, { scope: "latest" }).includes(j), false);
  j.uploadedAt = new Date().toISOString();
  assert.equal(d.queryJobs(db, { scope: "latest" }).includes(j), true);
  assert.ok(d.queryJobs(db, { date: d.day() }).includes(j));
});
test("筛选维度内OR维度间AND，学历包含高学历，不限日期不叠加72小时", () => {
  const db = seed();
  assert.equal(
    d.matches(db.jobs[0], {
      natures: ["央企", "国企"],
      degrees: ["硕士"],
      cities: ["上海"],
    }),
    true,
  );
  assert.equal(d.matches(db.jobs[0], { natures: ["私企"] }), false);
  assert.equal(d.matches(db.jobs[0], { majors: ["文学"] }), false);
  assert.ok(
    d.queryJobs(db, {}).length > d.queryJobs(db, { scope: "latest" }).length,
  );
});
test("敏感招聘链接服务端裁剪，收藏记录不改变公告", () => {
  const db = seed();
  assert.equal(d.serializeJob(db, db.jobs[0], db.users[1]).applyUrl, undefined);
  assert.ok(d.serializeJob(db, db.jobs[0], user(db)).applyUrl);
  const original = db.jobs[0].company;
  const r = d.saveRecord(db, user(db), {
    company: "个人名称",
    position: "自由岗位",
    status: "AI面",
    date: d.day(),
    jobId: db.jobs[0].id,
  });
  d.saveRecord(db, user(db), {
    company: "个人名称",
    position: "自由岗位",
    status: "Offer",
    date: d.day(),
    jobId: db.jobs[0].id,
  });
  assert.equal(r.history.length, 2);
  assert.equal(db.jobs[0].company, original);
});
test("日报消息按日期类型唯一，数量降零保留", () => {
  const db = seed();
  d.syncMessages(db);
  d.syncMessages(db);
  assert.equal(db.messages.filter((m) => m.mode === "new").length, 1);
  db.jobs.forEach((j) => (j.hidden = true));
  d.syncMessages(db);
  assert.equal(db.messages.find((m) => m.mode === "new").count, 0);
});
test("首个推荐固定，禁止自荐和循环，五个去重访问入团", () => {
  const db = seed();
  const a = user(db),
    b = db.users[1];
  d.bindReferral(db, b, a.id);
  d.bindReferral(db, b, db.users[2].id);
  assert.equal(b.referrerId, a.id);
  assert.throws(() => d.bindReferral(db, db.users[2], db.users[2].id));
  for (let i = 0; i < 4; i++) {
    const v = { id: "visitor" + i };
    db.users.push(v);
    d.visit(db, b.id, v.id);
    d.visit(db, b.id, v.id);
  }
  assert.equal(b.teamAt, undefined);
  db.users.push({ id: "visitor4" });
  d.visit(db, b.id, "visitor4");
  assert.ok(b.teamAt);
  assert.equal(db.visits.length, 5);
});
test("支付幂等，团队仅一层并按实付分别计算到分", () => {
  const db = seed();
  const a = user(db),
    b = db.users[1],
    c = db.users[2];
  b.distributor = true;
  b.referrerId = a.id;
  b.teamAt = new Date().toISOString();
  c.referrerId = b.id;
  const order = {
    id: "test",
    userId: c.id,
    status: "pending",
    type: "vip",
    days: 180,
    cents: 9999,
  };
  db.orders.push(order);
  d.settleOrder(db, order);
  d.settleOrder(db, order);
  assert.equal(db.ledger.filter((l) => l.orderId === "test").length, 2);
  assert.equal(
    db.ledger.find((l) => l.orderId === "test" && l.userId === b.id).cents,
    1000,
  );
  assert.equal(
    db.ledger.find((l) => l.orderId === "test" && l.userId === a.id).cents,
    500,
  );
  assert.equal(db.rights.filter((r) => r.orderId === "test").length, 1);
});
test("分销开通前订单不补佣金，未入团不结团队佣金", () => {
  const db = seed();
  const b = db.users[1],
    c = db.users[2];
  b.referrerId = user(db).id;
  c.referrerId = b.id;
  d.settleOrder(db, {
    id: "o1",
    userId: c.id,
    status: "pending",
    type: "vip",
    days: 30,
    cents: 10000,
  });
  assert.equal(db.ledger.filter((l) => l.orderId === "o1").length, 0);
  b.distributor = true;
  d.settleOrder(db, {
    id: "o2",
    userId: c.id,
    status: "pending",
    type: "vip",
    days: 30,
    cents: 10000,
  });
  assert.equal(db.ledger.filter((l) => l.orderId === "o2").length, 1);
});
test("提现冻结、防超额、撤销返回资金及状态限制", () => {
  const db = seed();
  const u = user(db),
    before = d.wallet(db, u.id).available;
  const w = d.createWithdrawal(db, u, {
    cents: 5000,
    method: "微信",
    name: "李",
    image: "data:image/png;base64,abc",
  });
  assert.equal(d.wallet(db, u.id).available, before - 5000);
  assert.equal(d.wallet(db, u.id).pending, 5000);
  assert.throws(() =>
    d.createWithdrawal(db, u, {
      cents: before,
      method: "微信",
      name: "李",
      image: "data:image/png;base64,abc",
    }),
  );
  d.changeWithdrawal(db, w, "cancel");
  assert.equal(d.wallet(db, u.id).available, before);
  assert.throws(() => d.changeWithdrawal(db, w, "cancel"));
});
test("退款撤单一权益、关闭相关未打款申请，冲回佣金不误撤高级身份", () => {
  const db = seed();
  const u = user(db),
    buyer = db.users[2];
  buyer.referrerId = u.id;
  const o = {
    id: "refund",
    userId: buyer.id,
    status: "pending",
    type: "partner",
    days: 0,
    cents: 10000,
  };
  db.orders.push(o);
  d.settleOrder(db, o);
  const w = d.createWithdrawal(db, u, {
    cents: 5000,
    method: "微信",
    name: "李",
    image: "data:image/png;base64,abc",
  });
  d.refundOrder(db, o, "测试退款");
  assert.equal(w.status, "已关闭");
  assert.equal(db.ledger.find((l) => l.kind === "reversal").cents, -2000);
  assert.equal(d.entitlement(db, buyer).type, "vip");
  assert.equal(d.entitlement(db, u).type, "senior");
  d.refundOrder(db, o, "重复");
  assert.equal(db.ledger.filter((l) => l.kind === "reversal").length, 1);
});
test("已提现佣金退款记待追回，未来收入优先抵扣", () => {
  const db = seed();
  const u = user(db),
    buyer = db.users[1];
  db.ledger = [];
  buyer.referrerId = u.id;
  const o = {
    id: "r",
    userId: buyer.id,
    status: "pending",
    type: "vip",
    days: 30,
    cents: 50000,
  };
  db.orders.push(o);
  d.settleOrder(db, o);
  const w = d.createWithdrawal(db, u, {
    cents: 10000,
    method: "微信",
    name: "李",
    image: "data:image/png;base64,abc",
  });
  d.changeWithdrawal(db, w, "approve", "", true);
  d.changeWithdrawal(db, w, "pay", "流水123", true);
  d.refundOrder(db, o, "退款");
  assert.equal(d.wallet(db, u.id).recovery, 10000);
  assert.throws(() =>
    d.createWithdrawal(db, u, {
      cents: 5000,
      method: "微信",
      name: "李",
      image: "data:image/png;base64,abc",
    }),
  );
  db.ledger.push({ userId: u.id, kind: "commission", cents: 12000 });
  assert.equal(d.wallet(db, u.id).available, 2000);
  assert.equal(d.wallet(db, u.id).recovery, 0);
});
test("赠送生成扣月额度，跨月过期退原月，不重复核销永久权益", () => {
  const db = seed();
  const u = user(db);
  const g = d.generateGift(
    db,
    u,
    { type: "vip", validDays: 7 },
    new Date("2026-10-30T12:00:00+08:00"),
  );
  assert.equal(d.quotas(db, u, new Date("2026-10-31"))[0].used, 1);
  assert.throws(() => d.redeemGift(db, u, g.code, new Date("2026-10-31")));
  assert.equal(g.status, "待领取");
  d.expireGifts(db, new Date("2026-11-08"));
  assert.equal(g.status, "已过期");
  assert.equal(d.quotas(db, u, new Date("2026-11-08"))[0].used, 0);
  assert.equal(d.quotas(db, u, new Date("2026-10-31"))[0].used, 0);
});
test("赠送一次领取，无购买单无佣金，取消高级权限作废未领", () => {
  const db = seed();
  const u = user(db),
    normal = db.users[1];
  const g = d.generateGift(db, u, { type: "vip", validDays: 7 });
  d.redeemGift(db, normal, g.code);
  assert.equal(g.status, "已领取");
  assert.throws(() => d.redeemGift(db, normal, g.code));
  assert.equal(db.orders.length, 0);
  const pending = d.generateGift(db, u, { type: "partner", validDays: 7 });
  d.revokeGiftPermission(db, u);
  assert.equal(pending.status, "已作废");
  assert.equal(g.status, "已领取");
  assert.throws(() => d.generateGift(db, u, { type: "vip", validDays: 7 }));
});
test("VIP续费顺延，撤回中间订单按独立来源重新计算", () => {
  const db = seed();
  const u = db.users[1];
  const at = new Date().toISOString();
  db.rights.push(
    { userId: u.id, type: "vip", days: 180, at },
    { userId: u.id, type: "vip", days: 365, at },
  );
  assert.ok(
    new Date(d.entitlement(db, u).expires) - new Date(at) >= 545 * 86400000,
  );
  db.rights[db.rights.length - 1].revoked = true;
  assert.equal(
    new Date(d.entitlement(db, u).expires) - new Date(at),
    180 * 86400000,
  );
});
test("省内全选展开城市与专业同义词按后台配置匹配", () => {
  const db = seed();
  assert.ok(
    d
      .queryJobs(db, { cities: ["广东"] })
      .every((j) =>
        j.cities.some((c) => ["广州", "深圳", "珠海", "东莞"].includes(c)),
      ),
  );
  assert.equal(d.queryJobs(db, { majors: ["CS"] }).length, 18);
});
test("商品类型、身份和续费佣金规则分别配置并保留支付快照", () => {
  const db = seed();
  const buyer = db.users[1];
  buyer.referrerId = user(db).id;
  db.config.commissionRules = [
    { type: "vip", tier: "senior", renewal: false, direct: 15, team: 4 },
    { type: "vip", tier: "senior", renewal: true, direct: 12, team: 3 },
  ];
  const first = {
    id: "first",
    userId: buyer.id,
    type: "vip",
    days: 30,
    cents: 10000,
    status: "pending",
  };
  db.orders.push(first);
  d.settleOrder(db, first);
  assert.equal(first.commissionSnapshot[0].rate, 15);
  const renewal = { ...first, id: "renew", status: "pending" };
  db.orders.push(renewal);
  d.settleOrder(db, renewal);
  assert.equal(renewal.renewal, true);
  assert.equal(renewal.commissionSnapshot[0].rate, 12);
  db.config.commissionRules[0].direct = 50;
  assert.equal(db.ledger.find((l) => l.orderId === "first").cents, 1500);
});
test("无效日期不能保存为个人进展", () => {
  const db = seed();
  assert.throws(() =>
    d.saveRecord(db, user(db), {
      company: "测试",
      position: "岗位",
      status: "已投递",
      date: "2026-02-31",
    }),
  );
});
