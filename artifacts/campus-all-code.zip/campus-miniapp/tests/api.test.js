import test from "node:test";
import assert from "node:assert/strict";
import { createApp } from "../server/app.js";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
test("REST鉴权、链接裁剪、记录免费、支付权限及角色隔离", async () => {
  const { app } = createApp();
  const server = app.listen(0);
  const base = `http://127.0.0.1:${server.address().port}/api`;
  let token;
  const api = async (path, method = "GET", body) => {
    const r = await fetch(base + path, {
      method,
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: "Bearer " + token } : {}),
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    return { status: r.status, data: await r.json() };
  };
  try {
    assert.equal((await api("/jobs/job-1")).status, 401);
    let login = await api("/auth/demo", "POST", { type: "normal" });
    token = login.data.token;
    let jobs = await api("/jobs?q=" + encodeURIComponent("{}"));
    assert.equal(jobs.data.items.length, 10);
    assert.equal(jobs.data.items[0].applyUrl, undefined);
    assert.equal((await api("/jobs?page=2")).status, 403);
    assert.equal((await api("/admin")).status, 403);
    assert.equal((await api("/gifts")).status, 403);
    const r = await api("/records", "POST", {
      company: "测试公司",
      position: "自由文本岗位",
      date: "2026-10-14",
      status: "已投递",
    });
    assert.equal(r.status, 200);
    const o = await api("/orders", "POST", { packageId: "vip-half" });
    assert.equal(
      (await api("/orders/" + o.data.id + "/pay", "POST", {})).status,
      200,
    );
    assert.equal((await api("/jobs?page=2")).status, 200);
    assert.ok((await api("/jobs/job-1")).data.applyUrl);
    assert.equal((await api("/records/" + r.data.id, "DELETE")).status, 200);
    token = (await api("/auth/demo", "POST", { type: "editor" })).data.token;
    assert.equal((await api("/admin")).status, 200);
    assert.equal(
      (await api("/admin/config", "PATCH", { closingDays: 5 })).status,
      403,
    );
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
});
test("SQLite保留已保存记录和会话，失败事务不留半成品", async () => {
  const dir = mkdtempSync(join(tmpdir(), "campus-test-"));
  const path = join(dir, "test.sqlite");
  let instance = createApp({ dbPath: path });
  const before = instance.getState().jobs.length;
  instance.getState().jobs[0].title = "持久化示例";
  let server = instance.app.listen(0);
  let base = `http://127.0.0.1:${server.address().port}/api`;
  await fetch(base + "/auth/demo", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: '{"type":"normal"}',
  });
  await new Promise((resolve) => server.close(resolve));
  instance.close();
  instance = createApp({ dbPath: path });
  assert.equal(instance.getState().jobs.length, before);
  assert.equal(instance.getState().jobs[0].title, "持久化示例");
  assert.equal(instance.getState().sessions.length, 1);
  instance.close();
  rmSync(dir, { recursive: true, force: true });
});
test("本人头像更新、消息阅读状态及受限个人收藏回看", async () => {
  const { app } = createApp();
  const server = app.listen(0);
  const base = `http://127.0.0.1:${server.address().port}/api`;
  const login = await fetch(base + "/auth/demo", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: '{"type":"normal"}',
  }).then((r) => r.json());
  const headers = {
    "Content-Type": "application/json",
    Authorization: "Bearer " + login.token,
  };
  try {
    const r = await fetch(base + "/profile", {
      method: "PATCH",
      headers,
      body: JSON.stringify({
        avatar: "data:image/png;base64,abc",
        nickname: "测试昵称",
      }),
    });
    assert.equal(r.status, 200);
    await fetch(base + "/favorites/job-18", { method: "POST", headers });
    assert.equal((await fetch(base + "/jobs/job-18", { headers })).status, 200);
    const messages = await fetch(base + "/messages", { headers }).then((r) =>
      r.json(),
    );
    assert.equal(messages[0].read, false);
    await fetch(base + "/messages/" + messages[0].id + "/read", {
      method: "POST",
      headers,
    });
    const read = await fetch(base + "/messages", { headers }).then((r) =>
      r.json(),
    );
    assert.equal(read.find((m) => m.id === messages[0].id).read, true);
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
});
test("生产模式禁止演示数据与模拟支付，初始化无默认已知密码", async () => {
  assert.throws(() => createApp({ demo: false, adminCredentials: {} }));
  const { app, getState } = createApp({
    demo: false,
    adminCredentials: {
      phone: "13912345678",
      password: "ProductionTestOnly123!",
    },
  });
  assert.equal(getState().users.length, 1);
  assert.equal(getState().jobs.length, 0);
  assert.equal(getState().ledger.length, 0);
  assert.equal(getState().config.packages.length, 0);
  const server = app.listen(0);
  try {
    const r = await fetch(
      `http://127.0.0.1:${server.address().port}/api/auth/demo`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: "{}",
      },
    );
    assert.equal(r.status, 404);
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
});
