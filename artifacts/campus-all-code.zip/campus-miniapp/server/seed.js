import { id, day, hashPassword } from "./domain.js";
export function seed() {
  const now = new Date();
  const at = (hours) => new Date(now.getTime() - hours * 3600000).toISOString();
  const future = (days) =>
    new Date(now.getTime() + days * 86400000).toISOString();
  const user = {
    id: "demo-senior",
    phone: "13800138000",
    password: hashPassword("Demo12345!"),
    nickname: "李思远",
    avatar: "李",
    batch: "2027届",
    major: "计算机科学与技术",
    seeking: "求职中",
    distributor: true,
    role: "user",
    referrerId: "demo-partner",
    at: at(24 * 30),
  };
  const users = [
    user,
    {
      ...user,
      id: "demo-normal",
      phone: "13800138001",
      nickname: "林同学",
      distributor: false,
      referrerId: null,
    },
    {
      ...user,
      id: "demo-vip",
      phone: "13800138002",
      nickname: "陈同学",
      distributor: false,
      referrerId: null,
    },
    {
      ...user,
      id: "demo-partner",
      phone: "13800138003",
      nickname: "王同学",
      referrerId: null,
    },
    {
      ...user,
      id: "demo-admin",
      phone: "13800138999",
      nickname: "超级管理员",
      role: "admin",
      referrerId: null,
    },
    {
      ...user,
      id: "demo-editor",
      phone: "13800138998",
      nickname: "招聘编辑",
      role: "editor",
      referrerId: null,
    },
  ];
  const companies = [
    ["中国移动", "央企", "通信", "mobile"],
    ["字节跳动", "私企", "互联网", "byte"],
    ["国家电网", "央企", "能源", "grid"],
    ["华为", "私企", "互联网", "huawei"],
    ["中国工商银行", "国企", "银行金融", "bank"],
    ["腾讯科技", "私企", "互联网", "tencent"],
    ["阿里巴巴", "私企", "互联网", "alibaba"],
    ["美团", "私企", "互联网", "meituan"],
    ["京东", "私企", "快消零售", "jd"],
    ["宝洁", "外企", "快消零售", "pg"],
    ["中国建设银行", "国企", "银行金融", "bank"],
    ["中国联通", "央企", "通信", "mobile"],
    ["小米", "私企", "互联网", "mi"],
    ["招商银行", "私企", "银行金融", "bank"],
    ["中国中车", "央企", "制造", "grid"],
    ["网易", "私企", "互联网", "netease"],
    ["联合利华", "外企", "快消零售", "pg"],
    ["中国南方航空", "央企", "交通", "grid"],
  ];
  const jobs = companies.map(([company, nature, industry, logo], i) => ({
    id: `job-${i + 1}`,
    company,
    nature,
    industry,
    logo,
    title: `${company}2027届秋季校园招聘`,
    type: "秋招专场",
    degree: "本科及以上",
    batch: "2027届",
    cities:
      i % 3 === 0
        ? ["北京", "上海", "深圳"]
        : i % 3 === 1
          ? ["上海", "杭州"]
          : ["北京", "广州"],
    start: at(24 * 30),
    deadline: i === 11 ? null : future(i === 2 ? 0 : (i % 8) + 1),
    uploadedAt: at(i < 6 ? i * 2 : i < 14 ? 20 + i : 26 + i * 3),
    createdAt: at(240),
    positions: ["技术类 120+", "产品类 50+", "运营类 30+", "市场类 20+"],
    majors: [
      "计算机科学与技术",
      "软件工程",
      "数学与应用数学",
      "信息与通信工程",
    ],
    intro: `${company}面向2027届毕业生开启秋季校园招聘。我们致力于以创新连接更多可能，为青年人才提供广阔的发展平台、系统的培养计划和开放的工作氛围。\n加入我们，你将参与具有影响力的项目，与优秀团队共同成长。欢迎有理想、敢探索的你，共同创造未来。`,
    sourceUrl: "https://example.com/recruitment",
    applyUrl: "https://example.com/apply",
    recommended: i < 5,
    recommendOrder: i,
    views: 1860 - i * 73,
    published: true,
    hidden: false,
    deleted: false,
  }));
  jobs.push({
    ...jobs[0],
    id: "job-draft",
    title: "未发布示例",
    published: false,
  });
  const records = [
    ["腾讯科技", "产品经理", "一面", "tencent"],
    ["阿里巴巴", "算法工程师", "AI面", "alibaba"],
    ["美团", "后端开发工程师", "Offer", "meituan"],
    ["字节跳动", "前端开发工程师", "已投递", "byte"],
    ["华为", "软件工程师", "笔试", "huawei"],
    ["中国移动", "产品运营", "已签约", "mobile"],
  ].map(([company, position, status, logo], i) => ({
    id: `record-${i}`,
    userId: user.id,
    company,
    position,
    status,
    logo,
    jobId: jobs.find((j) => j.company === company)?.id,
    initialDate: day(at(i * 24 * 3)),
    notes: i === 0 ? "已完成一面，等待后续通知。" : "",
    history: [
      {
        id: id(),
        status: "已投递",
        date: day(at(24 * (i + 4))),
        at: at(24 * (i + 4)),
      },
      { id: id(), status, date: day(at(i * 24)), at: at(i * 24) },
    ],
  }));
  return {
    mode: "demo",
    users,
    jobs,
    records,
    sessions: [],
    favorites: [
      { userId: user.id, jobId: "job-1" },
      { userId: user.id, jobId: "job-3" },
    ],
    rights: [
      {
        id: id(),
        userId: user.id,
        type: "senior",
        at: at(240),
        source: "演示授权",
      },
      {
        id: id(),
        userId: "demo-partner",
        type: "partner",
        at: at(240),
        source: "演示授权",
      },
      {
        id: id(),
        userId: "demo-vip",
        type: "vip",
        days: 365,
        at: at(240),
        source: "演示授权",
      },
    ],
    orders: [],
    gifts: [],
    visits: [],
    withdrawals: [],
    messages: [],
    views: [],
    audit: [],
    ledger: [
      {
        id: id(),
        userId: user.id,
        kind: "commission",
        channel: "直接",
        cents: 284420,
        rate: 20,
        orderId: "demo-history",
        at: at(0),
        demo: true,
      },
    ],
    config: {
      majorAliases: {
        计算机: ["计算机", "软件工程"],
        CS: ["计算机", "软件工程"],
      },
      commissionRules: [],
      closingDays: 7,
      ruleVersion: 1,
      giftMaxDays: 30,
      giftQuotas: [
        { type: "vip", days: 180, limit: 10 },
        { type: "partner", days: 0, limit: 2 },
      ],
      rates: {
        normal: { direct: 10, team: 0 },
        vip: { direct: 10, team: 0 },
        partner: { direct: 20, team: 5 },
        senior: { direct: 20, team: 5 },
      },
      packages: [
        {
          id: "vip-half",
          title: "半年会员",
          type: "vip",
          days: 180,
          cents: 5900,
          subtitle: "陪伴一个完整校招季",
        },
        {
          id: "vip-year",
          title: "一年会员",
          type: "vip",
          days: 365,
          cents: 9900,
          subtitle: "春招秋招，从容准备",
          recommended: true,
        },
        {
          id: "vip-two",
          title: "两年会员",
          type: "vip",
          days: 730,
          cents: 16900,
          subtitle: "长期规划，更进一步",
        },
        {
          id: "partner",
          title: "职场合伙人",
          type: "partner",
          days: 0,
          cents: 29900,
          subtitle: "永久 VIP · 团队权益",
        },
      ],
      topics: [
        { id: "all", name: "全部", icon: "grid", color: "#007AFF", query: {} },
        {
          id: "state",
          name: "央国企",
          icon: "building",
          color: "#E5484D",
          query: { natures: ["央企", "国企"] },
        },
        {
          id: "internet",
          name: "互联网",
          icon: "monitor",
          color: "#007AFF",
          query: { search: "", industries: ["互联网"] },
        },
        {
          id: "bank",
          name: "银行金融",
          icon: "bank",
          color: "#F59A23",
          query: { industries: ["银行金融"] },
        },
        {
          id: "retail",
          name: "快消零售",
          icon: "bag",
          color: "#1B9A67",
          query: { industries: ["快消零售"] },
        },
      ],
      dictionaries: {
        natures: ["央企", "国企", "私企", "外企"],
        degrees: ["本科", "硕士", "博士", "大专"],
        batches: ["2026届", "2027届", "2028届"],
        types: ["秋招专场", "春招专场", "社会招聘", "实习专场"],
      },
      locations: {
        北京: ["北京"],
        上海: ["上海"],
        广东: ["广州", "深圳", "珠海", "东莞"],
        浙江: ["杭州", "宁波"],
        江苏: ["南京", "苏州"],
        四川: ["成都"],
        湖北: ["武汉"],
        山东: ["济南", "青岛"],
        福建: ["福州", "厦门"],
        陕西: ["西安"],
        湖南: ["长沙"],
        河南: ["郑州"],
        河北: ["石家庄"],
        安徽: ["合肥"],
        重庆: ["重庆"],
        天津: ["天津"],
        辽宁: ["沈阳", "大连"],
        吉林: ["长春"],
        黑龙江: ["哈尔滨"],
        江西: ["南昌"],
        广西: ["南宁"],
        云南: ["昆明"],
        贵州: ["贵阳"],
        山西: ["太原"],
        内蒙古: ["呼和浩特"],
        海南: ["海口"],
        甘肃: ["兰州"],
        宁夏: ["银川"],
        青海: ["西宁"],
        新疆: ["乌鲁木齐"],
        西藏: ["拉萨"],
        台湾: ["台北"],
        香港: ["香港"],
        澳门: ["澳门"],
      },
      help: [
        {
          title: "如何添加投递进展？",
          body: "在招聘详情点击添加进展，或在投递记录点击右下角加号。收藏和投递管理向所有已登录用户免费开放。",
        },
        {
          title: "会员和合伙人有什么区别？",
          body: "VIP 按套餐有效期享有无限浏览权益；合伙人拥有永久 VIP 权益与团队佣金资格。高级合伙人由管理员授权。",
        },
        {
          title: "如何申请提现？",
          body: "开通分销后，可在分销中心申请提现，最低50元。收款资料提交后由管理员审核。",
        },
        {
          title: "联系客服",
          body: "演示环境尚未配置线上客服。上线前由管理员设置客服联系方式。",
        },
      ],
    },
  };
}

export function productionSeed({ phone, password } = {}) {
  if (!/^1\d{10}$/.test(phone || "") || (password || "").length < 12)
    throw new Error("生产初始化需设置ADMIN_PHONE与至少12位ADMIN_PASSWORD");
  const state = seed();
  state.mode = "production";
  for (const key of [
    "users",
    "jobs",
    "records",
    "sessions",
    "favorites",
    "rights",
    "orders",
    "gifts",
    "visits",
    "withdrawals",
    "messages",
    "views",
    "audit",
    "ledger",
  ])
    state[key] = [];
  state.users.push({
    id: id(),
    phone,
    password: hashPassword(password),
    nickname: "管理员",
    avatar: "管",
    role: "admin",
    at: new Date().toISOString(),
  });
  state.config.packages = [];
  return state;
}
