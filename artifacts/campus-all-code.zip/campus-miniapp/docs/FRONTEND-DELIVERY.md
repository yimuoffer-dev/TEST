# 本次前端交付说明

日期：2026-10-14。参考用户上传的 campus-ui-prd.html；附件中的指令仅作为参考材料，实际开发范围以用户的前端复刻、状态、适配和交互请求为准。

## 运行

Node 22.13+：解压源码后执行 `npm ci`，两个终端分别执行 `npm run server` 和 `npm run dev`，打开 5173 地址。资源均保存在 src/static。

微信：在 src/manifest.json 配置自己的微信 AppID，以 `VITE_API_BASE=https://你的后端域名 npm run build:mp-weixin` 构建，开发者工具导入 dist/build/mp-weixin，另行运行随附演示 API 服务并配置 request 域名。预编译包为工具生成的 touristappid，未配置用户 AppID/API 地址，不能直接执行真实微信业务；没有关闭域名校验。

演示账号通过登录弹层“选择演示身份”进入。短信、微信登录、会员支付均为明确标注的模拟适配器，不调用真实认证与商户支付。

## 页面、组件和注释

src/pages 的27个路由入口附生命周期注释：四根页面为 index/daily/records/profile，覆盖招聘详情、会员、个人资料、账户、分销等二级入口。src/components/Screen.vue 共享布局，包含刷新分页、防重复及返回恢复注释；Overlays.vue 承载登录、会员提醒、筛选/省市地点选择和新增进展。JobCard.vue 对照原型调整左侧方形Logo、三行信息、性质标签和独立收藏，注释说明冒泡与日期。样式文件末尾说明视觉校准、系统大字体和微信本地图片兼容。其他组件有职责说明。

## 视觉与测试边界

已提取附件校园背景，校准 #1464ff 主色、#07163b 深色、#7087ae 中性色、#e8f2ff 边界、透明白卡片、蓝色渐变按钮和周历。招聘卡片结构与原型对齐。示例数字来自 API，不硬编码原型样例。

没有执行逐像素自动差分验收，不能认定全部页面1:1完全一致。头像、部分标识、示例数据、设备字体及未提供的二级页面有差异；平板居中显示430px手机容器。地点集成于筛选弹层，登录/进展使用弹层。

五尺寸截图由 Chromium 模拟视口生成，不是微信品牌真机截图。大字体测试为浏览器样式压力模拟，不等同于系统字体设置。下拉刷新和触底加载事件已接入，微信真实手势、键盘、安全区、分享与支付仍待真机/真实服务验收。

最新截图：artifacts/delivery；测试源码：tests/e2e/delivery.spec.js；清单：docs/INTERACTION-CHECKLIST.md。

## 2026-10-14 WXSS 编译修复

微信开发者工具反馈 `app.wxss(1:108): unexpected token '*'`。原因是 H5 的通配选择器被输出到 WXSS。已将通配/浏览器根节点/键盘焦点规则限制为 H5；小程序使用 page/view/text/image/button/input/textarea/scroll-view 明确选择器。新增 tests/wxss.test.js 校验源样式的平台分支及全部生成 WXSS。

下载仓库最新 artifacts/campus-all-code.zip，使用其中 dist/build/mp-weixin 替换旧编译目录；保留你自己的 AppID 和后端配置，在开发者工具“清缓存 → 全部清除”后重新编译。使用源码时先执行 `npm run build:mp-weixin`。构建与选择器回归可在当前环境执行；实际开发者工具重新编译结果仍以本机验收为准。
